#ifndef CORE_STRING_HPP
#define CORE_STRING_HPP

#include <initializer_list>
#include <functional>
#include <stdexcept>
#include <algorithm>
#include <iterator>
#include <string>
#include <limits>

#include <cstdlib>

namespace core {
inline namespace v1 {

#ifndef CORE_NO_EXCEPTIONS
[[noreturn]] inline void throw_out_of_range (char const* msg) {
  throw ::std::out_of_range { msg };
}
#else /* CORE_NO_EXCEPTIONS */
[[noreturn]] inline void throw_out_of_range (char const*) { ::std::abort(); }
#endif /* CORE_NO_EXCEPTIONS */

template <class CharT, class Traits=::std::char_traits<CharT>>
struct basic_string_view {
  using difference_type = ::std::ptrdiff_t;
  using value_type = CharT;
  using size_type = ::std::size_t;

  using reference = value_type const&;
  using pointer = value_type const*;

  using const_reference = reference;
  using const_pointer = pointer;

  using const_iterator = pointer;
  using iterator = const_iterator;

  using const_reverse_iterator = ::std::reverse_iterator<const_iterator>;
  using reverse_iterator = const_reverse_iterator;

  using traits = Traits;

  static constexpr size_type npos = ::std::numeric_limits<size_type>::max();

  template <class Allocator>
  basic_string_view (
    ::std::basic_string<CharT, Traits, Allocator> const& that
  ) : str { that.data() }, len { that.size() } { }

  constexpr basic_string_view (pointer str, size_type len) noexcept :
    str { str },
    len { len }
  { }

  basic_string_view (pointer str) noexcept :
    basic_string_view { str, traits::length(str) }
  { }

  constexpr basic_string_view (basic_string_view const& that) noexcept :
    str { that.str },
    len { that.len }
  { }

  constexpr basic_string_view () noexcept :
    str { nullptr },
    len { 0 }
  { }

  basic_string_view& operator = (basic_string_view const& that) noexcept {
    basic_string_view { that }.swap(*this);
    return *this;
  }

  template <class Allocator>
  explicit operator ::std::basic_string<CharT, Traits, Allocator> () const {
    return ::std::basic_string<CharT, Traits, Allocator> {
      this->data(),
      this->size()
    };
  }

  template <class Allocator=std::allocator<CharT>>
  ::std::basic_string<CharT, Traits, Allocator> to_string (
    Allocator const& allocator = Allocator()
  ) const {
    return ::std::basic_string<CharT, Traits, Allocator> {
      this->data(),
      this->size(),
      allocator
    };
  }

  constexpr const_iterator begin () const noexcept { return this->data(); }
  constexpr const_iterator end () const noexcept {
    return this->data() + this->size();
  }

  constexpr const_iterator cbegin () const noexcept { return this->begin(); }
  constexpr const_iterator cend () const noexcept { return this->end(); }

  const_reverse_iterator rbegin () const noexcept {
    return const_reverse_iterator { this->end()};
  }

  const_reverse_iterator rend () const noexcept {
    return const_reverse_iterator { this->begin() };
  }

  const_reverse_iterator crbegin () const noexcept { return this->rbegin(); }
  const_reverse_iterator crend () const noexcept { return this->rend(); }

  constexpr size_type max_size () const noexcept { return this->size(); }
  constexpr size_type length () const noexcept { return this->size(); }
  constexpr size_type size () const noexcept { return this->len; }

  constexpr bool empty () const noexcept { return this->size() == 0; }

  constexpr reference operator [] (size_type idx) const {
    return this->str[idx];
  }

  constexpr reference front () const { return this->str[0]; }
  constexpr reference back () const { return this->str[this->size() - 1]; }
  constexpr pointer data () const { return this->str; }

  void remove_prefix (size_type n) {
    if (n > this->size()) { n = this->size(); }
    this->str += n;
    this->len -= n;
  }

  void remove_suffix (size_type n) {
    if (n > this->size()) { n = this->size(); }
    this->len -= n;
  }

  void clear () noexcept {
    this->str = nullptr;
    this->len = 0;
  }

  size_type copy (CharT* s, size_type n, size_type pos = 0) const {
    if (pos > this->size()) {
      throw_out_of_range("position greater than size");
    }
    auto const rlen = std::min(n, this->size() - pos);
    ::std::copy_n(this->begin() + pos, rlen, s);
    return rlen;
  }

  constexpr basic_string_view substr (
    size_type pos=0,
    size_type n=npos
  ) const noexcept {
    return pos > this->size()
      ? (throw_out_of_range("start position out of range"), *this)
      : basic_string_view {
        this->data() + pos,
        n == npos or pos + n > this->size()
          ? (this->size() - pos)
          : n
      };
  }

  bool starts_with (value_type value) const noexcept {
    return not this->empty() and traits::eq(value, this->front());
  }

  bool ends_with (value_type value) const noexcept {
    return not this->empty() and traits::eq(value, this->back());
  }

  bool starts_with (basic_string_view that) const noexcept {
    return this->size() >= that.size() and
      traits::compare(this->data(), that.data(), that.size()) == 0;
  }

  bool ends_with (basic_string_view that) const noexcept {
    return this->size() >= that.size() and
      traits::compare(
        this->data() + this->size() - that.size(),
        that.data(),
        that.size()
      ) == 0;
  }

  /* compare */
  difference_type compare (basic_string_view s) const noexcept {
    auto cmp = traits::compare(
      this->data(),
      s.data(),
      ::std::min(this->size(), s.size())
    );

    if (cmp != 0) { return cmp; }
    if (this->size() == s.size()) { return 0; }
    if (this->size() < s.size()) { return -1; }
    return 1;
  }

  difference_type compare (
    size_type pos,
    size_type n,
    basic_string_view s
  ) const noexcept { return this->substr(pos, n).compare(s); }

  difference_type compare (
    size_type pos1,
    size_type n1,
    basic_string_view s,
    size_type pos2,
    size_type n2
  ) const noexcept {
    return this->substr(pos1, n1).compare(s.substr(pos2, n2));
  }

  difference_type compare (pointer s) const noexcept {
    return this->compare(basic_string_view { s });
  }

  difference_type compare (
    size_type pos,
    size_type n,
    pointer s
  ) const noexcept {
    return this->substr(pos, n).compare(basic_string_view { s });
  }

  difference_type compare (
    size_type pos,
    size_type n1,
    pointer s,
    size_type n2
  ) const noexcept {
    return this->substr(pos, n1).compare(basic_string_view { s, n2 });
  }

  reference at (size_type idx) const {
    static constexpr auto error = "requested index out of range";
    if (idx >= this->size()) { throw_out_of_range(error); }
    return this->str[idx];
  }

  /* find-first-not-of */
  size_type find_first_not_of (
    basic_string_view str,
    size_type pos = 0) const noexcept {
    if (pos > this->size()) { return npos; }
    auto begin = this->begin() + pos;
    auto end = this->end();
    auto const predicate = [str] (value_type v) { return str.find(v) == npos; };
    auto iter = std::find_if(begin, end, predicate);
    if (iter == end) { return npos; }
    return static_cast<size_type>(::std::distance(this->begin(), iter));
  }

  size_type find_first_not_of (
    pointer s,
    size_type pos,
    size_type n) const noexcept {
      return this->find_first_not_of(basic_string_view { s, n }, pos);
  }

  size_type find_first_not_of (pointer s, size_type pos = 0) const noexcept {
    return this->find_first_not_of(basic_string_view { s }, pos);
  }

  size_type find_first_not_of (value_type c, size_type pos = 0) const noexcept {
    return this->find_first_not_of(
      basic_string_view { ::std::addressof(c), 1 },
      pos);
  }

  /* find-first-of */
  size_type find_first_of (
    basic_string_view str,
    size_type pos = 0) const noexcept {
    if (pos > this->size()) { return npos; }
    auto iter = ::std::find_first_of(
      this->begin() + pos, this->end(),
      str.begin(), str.end(),
      traits::eq);
    if (iter == this->end()) { return npos; }
    return static_cast<size_type>(::std::distance(this->begin(), iter));
  }

  size_type find_first_of (pointer s, size_type p, size_type n) const noexcept {
    return this->find_first_of(basic_string_view { s, n }, p);
  }

  size_type find_first_of (pointer s, size_type pos = 0) const noexcept {
    return this->find_first_of(basic_string_view { s }, pos);
  }

  size_type find_first_of (value_type c, size_type pos = 0) const noexcept {
    return this->find_first_of(
      basic_string_view { ::std::addressof(c), 1 },
      pos);
  }

  /* find */
  size_type find (basic_string_view str, size_type pos = 0) const noexcept {
    if (pos >= this->size()) { return npos; }
    auto iter = ::std::search(
      this->begin() + pos, this->end(),
      str.begin(), str.end(),
      traits::eq);
    if (iter == this->end()) { return npos; }
    return static_cast<size_type>(::std::distance(this->begin(), iter));
  }

  size_type find (pointer s, size_type p, size_type n) const noexcept {
    return this->find(basic_string_view { s, n }, p);
  }

  size_type find (pointer s, size_type pos = 0) const noexcept {
    return this->find(basic_string_view { s }, pos);
  }

  size_type find (value_type c, size_type pos = 0) const noexcept {
    return this->find(basic_string_view { ::std::addressof(c), 1 }, pos);
  }

  size_type find_last_not_of (
    basic_string_view str,
    size_type pos = npos) const noexcept {
    auto const offset = this->size() - ::std::min(this->size(), pos);
    auto begin = this->rbegin() + static_cast<difference_type>(offset);
    auto end = this->rend();
    auto const predicate = [str] (value_type v) { return str.find(v) == npos; };
    auto iter = ::std::find_if(begin, end, predicate);
    if (iter == end) { return npos; }
    auto const distance = static_cast<size_type>(
      ::std::distance(this->rbegin(), iter));
    return this->size() - distance - 1;
  }

  size_type find_last_not_of (
    pointer s,
    size_type p,
    size_type n) const noexcept {
    return this->find_last_not_of(basic_string_view { s, n }, p);
  }

  size_type find_last_not_of (pointer s, size_type p = npos) const noexcept {
    return this->find_last_not_of(basic_string_view { s }, p);
  }

  size_type find_last_not_of (
    value_type c,
    size_type pos = npos) const noexcept {
    return this->find_last_not_of(
      basic_string_view { ::std::addressof(c), 1 },
      pos);
  }

  size_type find_last_of (
    basic_string_view str,
    size_type pos = npos) const noexcept {
    auto const offset = this->size() - ::std::min(this->size(), pos);
    auto begin = this->rbegin() + static_cast<difference_type>(offset);
    auto end = this->rend();

    auto iter = ::std::find_first_of(
      begin, end,
      str.rbegin(), str.rend(),
      traits::eq);
    if (iter == end) { return npos; }
    auto const distance = static_cast<size_type>(
      ::std::distance(this->rbegin(), iter));
    return this->size() - distance - 1;
  }

  size_type find_last_of (pointer s, size_type p, size_type n) const noexcept {
    return this->find_last_of(basic_string_view { s, n }, p);
  }

  size_type find_last_of (pointer s, size_type p=npos) const noexcept {
    return this->find_last_of(basic_string_view { s }, p);
  }

  size_type find_last_of (value_type c, size_type p=npos) const noexcept {
    return this->find_last_of(basic_string_view { ::std::addressof(c), 1 }, p);
  }

  size_type rfind (basic_string_view str, size_type pos=npos) const noexcept {
    auto const offset = this->size() - ::std::min(this->size(), pos);
    auto begin = this->rbegin() + offset;
    auto end = this->rend();
    auto iter = ::std::search(
      begin, end,
      str.rbegin(), str.rend(),
      traits::eq);
    if (iter == end) { return npos; }
    auto const distance = static_cast<size_type>(
      ::std::distance(this->rbegin(), iter));
    return this->size() - distance - 1;
  }

  size_type rfind (pointer s, size_type p, size_type n) const noexcept {
    return this->rfind(basic_string_view { s, n }, p);
  }

  size_type rfind (pointer s, size_type p=npos) const noexcept {
    return this->rfind(basic_string_view { s }, p);
  }

  size_type rfind (value_type c, size_type p=npos) const noexcept {
    return this->rfind(basic_string_view { ::std::addressof(c), 1 }, p);
  }

  void swap (basic_string_view& that) noexcept {
    using ::std::swap;
    swap(this->str, that.str);
    swap(this->len, that.len);
  }

private:
  pointer str;
  size_type len;
};

using u32string_view = basic_string_view<char32_t>;
using u16string_view = basic_string_view<char16_t>;
using wstring_view = basic_string_view<wchar_t>;
using string_view = basic_string_view<char>;

/* string_view comparison string_view */
template <class CharT, typename Traits>
bool operator == (
  basic_string_view<CharT, Traits> lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return lhs.size() == rhs.size() and lhs.compare(rhs) == 0; }

template <class CharT, typename Traits>
bool operator != (
  basic_string_view<CharT, Traits> lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return lhs.size() != rhs.size() or lhs.compare(rhs) != 0; }

template <class CharT, typename Traits>
bool operator >= (
  basic_string_view<CharT, Traits> lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return lhs.compare(rhs) >= 0; }

template <class CharT, typename Traits>
bool operator <= (
  basic_string_view<CharT, Traits> lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return lhs.compare(rhs) <= 0; }

template <class CharT, typename Traits>
bool operator > (
  basic_string_view<CharT, Traits> lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return lhs.compare(rhs) > 0; }

template <class CharT, typename Traits>
bool operator < (
  basic_string_view<CharT, Traits> lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return lhs.compare(rhs) < 0; }

/* string_view comparison string */
template <class CharT, class Traits, class Allocator>
bool operator == (
  basic_string_view<CharT, Traits> lhs,
  ::std::basic_string<CharT, Traits, Allocator> const& rhs
) noexcept { return lhs == basic_string_view<CharT, Traits> { rhs }; }

template <class CharT, class Traits, class Allocator>
bool operator != (
  basic_string_view<CharT, Traits> lhs,
  ::std::basic_string<CharT, Traits, Allocator> const& rhs
) noexcept { return lhs != basic_string_view<CharT, Traits> { rhs }; }

template <class CharT, class Traits, class Allocator>
bool operator >= (
  basic_string_view<CharT, Traits> lhs,
  ::std::basic_string<CharT, Traits, Allocator> const& rhs
) noexcept { return lhs >= basic_string_view<CharT, Traits> { rhs }; }

template <class CharT, class Traits, class Allocator>
bool operator <= (
  basic_string_view<CharT, Traits> lhs,
  ::std::basic_string<CharT, Traits, Allocator> const& rhs
) noexcept { return lhs <= basic_string_view<CharT, Traits> { rhs }; }

template <class CharT, class Traits, class Allocator>
bool operator > (
  basic_string_view<CharT, Traits> lhs,
  ::std::basic_string<CharT, Traits, Allocator> const& rhs
) noexcept { return lhs > basic_string_view<CharT, Traits> { rhs }; }

template <class CharT, class Traits, class Allocator>
bool operator < (
  basic_string_view<CharT, Traits> lhs,
  ::std::basic_string<CharT, Traits, Allocator> const& rhs
) noexcept { return lhs < basic_string_view<CharT, Traits> { rhs }; }

/* string comparison string_view */
template <class CharT, class Traits, class Allocator>
bool operator == (
  ::std::basic_string<CharT, Traits, Allocator> const& lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } == rhs; }

template <class CharT, class Traits, class Allocator>
bool operator != (
  ::std::basic_string<CharT, Traits, Allocator> const& lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } != rhs; }

template <class CharT, class Traits, class Allocator>
bool operator >= (
  ::std::basic_string<CharT, Traits, Allocator> const& lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } >= rhs; }

template <class CharT, class Traits, class Allocator>
bool operator <= (
  ::std::basic_string<CharT, Traits, Allocator> const& lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } <= rhs; }

template <class CharT, class Traits, class Allocator>
bool operator > (
  ::std::basic_string<CharT, Traits, Allocator> const& lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } > rhs; }

template <class CharT, class Traits, class Allocator>
bool operator < (
  ::std::basic_string<CharT, Traits, Allocator> const& lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } < rhs; }

/* string_view comparison CharT* */
template <class CharT, class Traits>
bool operator == (
  basic_string_view<CharT, Traits> lhs,
  CharT const* rhs
) noexcept { return lhs == basic_string_view<CharT, Traits> { rhs }; }

template <class CharT, class Traits>
bool operator != (
  basic_string_view<CharT, Traits> lhs,
  CharT const* rhs
) noexcept { return lhs != basic_string_view<CharT, Traits> { rhs }; }

template <class CharT, class Traits>
bool operator >= (
  basic_string_view<CharT, Traits> lhs,
  CharT const* rhs
) noexcept { return lhs >= basic_string_view<CharT, Traits> { rhs }; }

template <class CharT, class Traits>
bool operator <= (
  basic_string_view<CharT, Traits> lhs,
  CharT const* rhs
) noexcept { return lhs <= basic_string_view<CharT, Traits> { rhs }; }

template <class CharT, class Traits>
bool operator > (
  basic_string_view<CharT, Traits> lhs,
  CharT const* rhs
) noexcept { return lhs > basic_string_view<CharT, Traits> { rhs }; }

template <class CharT, class Traits>
bool operator < (
  basic_string_view<CharT, Traits> lhs,
  CharT const* rhs
) noexcept { return lhs < basic_string_view<CharT, Traits> { rhs }; }

/* CharT* comparison string_view */
template <class CharT, class Traits>
bool operator == (
  CharT const* lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } == rhs; }

template <class CharT, class Traits>
bool operator != (
  CharT const* lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } != rhs; }

template <class CharT, class Traits>
bool operator >= (
  CharT const* lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } >= rhs; }

template <class CharT, class Traits>
bool operator <= (
  CharT const* lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } <= rhs; }

template <class CharT, class Traits>
bool operator > (
  CharT const* lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } > rhs; }

template <class CharT, class Traits>
bool operator < (
  CharT const* lhs,
  basic_string_view<CharT, Traits> rhs
) noexcept { return basic_string_view<CharT, Traits> { lhs } < rhs; }

template <class CharT, class Traits>
::std::basic_ostream<CharT, Traits>& operator << (
  ::std::basic_ostream<CharT, Traits>& os,
  basic_string_view<CharT, Traits> const& str
) { return os << str.to_string(); }

template <class CharT, class Traits>
void swap (
  basic_string_view<CharT, Traits>& lhs,
  basic_string_view<CharT, Traits>& rhs
) noexcept { return lhs.swap(rhs); }

}} /* namespace core::v1 */

namespace std {

template <typename CharT, typename Traits>
struct hash<core::v1::basic_string_view<CharT, Traits>> {
  using argument_type = core::v1::basic_string_view<CharT, Traits>;
  using result_type = size_t;

  result_type operator ()(argument_type const& ref) const noexcept {
    return hash<typename argument_type::pointer> { }(ref.data());
  }
};

} /* namespace std */

#endif /* CORE_STRING_HPP */
